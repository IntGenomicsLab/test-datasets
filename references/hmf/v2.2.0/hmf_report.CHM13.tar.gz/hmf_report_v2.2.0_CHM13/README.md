# HMF report resources, CHM13 (lifted from oncoanalyser bundle v2.2.0)

The GRCh38 resources of `hmf_pipeline_resources.38_v2.2.0--3` lifted to T2T-CHM13v2.0 by
LRSomatic's `bin/hmf_liftover.py` (IntGenomicsLab/lrsomatic commit a7fd387) with the T2T consortium's
`grch38-chm13v2.chain` (v1_nflo, CC0; md5 913bb9a3352e88c23010d968d8b3af8c) and the
chm13v2.0_maskedY_rCRS FASTA, in the bundle's own layout (works as `--report_hmf_resource_dir`).

- Ensembl cache: canonical transcripts only, each kept only if every exon lifted whole onto one
  contig and strand in rank order (38,946 of 39,500; 528 of 530 driver-panel genes, OR4F21 and
  TPTE dropped). `common/ensembl_data/REFERENCE` declares `t2t`.
- Hotspots: REF re-checked on CHM13 (9,302 of 9,305), `##assembly=T2T-CHM13v2.0`.
- Actionable coding panel (6,587 regions) and the known fusions' IG/enhancer/3' ranges (26) lifted.
- `hmf_liftover_report.tsv`: what was lifted and dropped, per resource.

Built 2026-11-26. Do not modify in place; a new version goes in a new folder.
