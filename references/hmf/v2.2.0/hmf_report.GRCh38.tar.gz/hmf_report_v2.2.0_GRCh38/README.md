# HMF report resources, GRCh38 (oncoanalyser bundle v2.2.0)

The five resources the LRSomatic report's optional HMF driver annotation reads, taken from the
Hartwig Medical Foundation oncoanalyser resource bundle `hmf_pipeline_resources.38_v2.2.0--3`,
in the bundle's own layout (so the directory works as `--report_hmf_resource_dir`).

- `common/DriverGenePanel.38.tsv`, `dna/sv/known_fusion_data.38.csv`,
  `dna/variants/KnownHotspots.somatic.38.vcf.gz`, `dna/variants/ActionableCodingPanel.38.bed.gz`,
  `common/ensembl_data/ensembl_gene_data.csv`: copied unchanged.
- `common/ensembl_data/ensembl_trans_exon_data.csv`: reduced to the canonical transcripts'
  rows (`CanonicalTranscriptId == TransId`, 247,408 of 1,532,157), the only rows the report
  reads.
- `common/ensembl_data/REFERENCE`: declares the build (`hg38`).

Built 2026-11-26 for IntGenomicsLab/lrsomatic (commit a7fd387). Do not modify in place; a new bundle
version goes in a new folder.
